package org.shogun.service;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.persistence.ManyToMany;

import org.hibernate.collection.PersistentSet;
import org.shogun.exception.ShogunDatabaseAccessException;
import org.shogun.exception.ShogunServiceException;
import org.shogun.hibernatecriteria.filter.HibernateFilter;
import org.shogun.hibernatecriteria.paging.HibernatePagingObject;
import org.shogun.hibernatecriteria.sort.HibernateSortObject;
import org.shogun.jsonrequest.Paging;
import org.shogun.jsonrequest.Request;
import org.shogun.jsonrequest.Sort;
import org.shogun.jsonrequest.association.Association;
import org.shogun.model.BaseModel;
import org.shogun.model.BaseModelInheritance;
import org.shogun.model.Module;
import org.shogun.model.User;
import org.shogun.util.JsHelper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * A basic service class of SHOGun offering some business logic.
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 */
@Service
public class ShogunService extends AbstractShogunService {

	/**
	 * Get Entities defined within a request Request defines filter, sorting and
	 * paging
	 * 
	 * @return List<Object>
	 * @throws ShogunServiceException 
	 */
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN') or hasRole('ROLE_SUPERADMIN')")
	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public Map<String, Object> getEntities(Request request) throws ShogunServiceException {
		
		HibernateSortObject hibernateSortObject = null;
		HibernateFilter hibernateFilter = null;
		HibernateFilter hibernateAdditionalFilter = null;
		HibernatePagingObject hibernatePaging = null;

		try {

			String objectType = request.getObject_type();
			
			Class clazz = Class.forName("org.shogun.model." + objectType);

			// get the criteria objects from client request
			Sort sortObject = request.getSortObject();
			org.shogun.jsonrequest.Filter filter = request.getFilter();
			org.shogun.jsonrequest.Filter additionalFilter = request.getGlobalAndFilter();
			Paging paging = request.getPagingObject();

			hibernateSortObject = HibernateSortObject.create(clazz, sortObject);
			hibernateFilter = HibernateFilter.create(clazz, filter);
			// needed to be able to have another global conjunction
			// temporary solution
			hibernateAdditionalFilter = HibernateFilter.create(clazz, additionalFilter);
			hibernatePaging = HibernatePagingObject.create(clazz, paging);

			// get total count
			long total = getDatabaseDAO().getTotal(hibernateFilter, hibernateAdditionalFilter);

			// get the data
			List<Object> dataList = null;

			// treat GROUP as a special case because of sub entities
			if (objectType.equals("Group")) {
				dataList = this.getDatabaseDAO().getDataByFilter(hibernateSortObject,
						hibernateFilter, hibernatePaging,
						hibernateAdditionalFilter);
			} else {
				dataList = this.getDatabaseDAO().getDataByFilter(hibernateSortObject,
						hibernateFilter, hibernatePaging,
						hibernateAdditionalFilter);
			}
			
			//TODO introduce a Beans abstracting this
			Map<String, Object> returnMap = new HashMap<String, Object>();
			returnMap.put("total", new Long(total));
			returnMap.put("data", dataList);
			returnMap.put("success", true);

			return returnMap;

		} catch (Exception e) {

			e.printStackTrace();

			throw new ShogunServiceException("Undefined error while requesting data " + e.getMessage() );
		}
	}

	
	/**
	 * TODO return a valid number
	 * TODO exception handling
	 * TODO refer to constant for package
	 * TODO cleanup
	 * 
	 * @param association
	 * @return
	 * @throws IntrospectionException
	 */
	@Transactional
	public Integer updateAssociation(Association association) throws IntrospectionException {
		
		Class<?> leftClazz;
		Class<?> rightClazz;
		Integer leftEntityId;
		List<Integer> assocications;
		
		Map<String, String> associationProperties;
		Method rightGetter;
		
		try {
			
			leftClazz = Class.forName("org.shogun.model." + association.getLeftEntity());
			rightClazz = Class.forName("org.shogun.model." + association.getRightEntity());
			leftEntityId = association.getLeftEntityId();
			assocications = association.getAssociations();
			
			// getter setter and property which is associated
			associationProperties = this.detectAssociationProperties(rightClazz, leftClazz);
			
			// Method object representing the getter-method of the right class, that returns the
			// list of left-class-objects, e.g. User.getMapLayers()
			System.out.println("Create a method object for " + associationProperties.get("assocGetter"));
			rightGetter = rightClazz.getMethod(associationProperties.get("assocGetter"));
			
			
			BaseModelInheritance wmsMapLayerInstanceToAdd = (BaseModelInheritance)this.getDatabaseDAO().getEntityById(leftEntityId, leftClazz, 0);
			
			List<Object> allUsers = this.getDatabaseDAO().getAllEntities(rightClazz);
			
			List<? extends Object> allnewAssocedUsers = this.getDatabaseDAO().getEntitiesByIds(assocications.toArray(), rightClazz);
			
			for (Iterator iterator = allnewAssocedUsers.iterator(); iterator.hasNext();) {
				
				
				BaseModel currentAssocedUser = (BaseModel) iterator.next();
				
				// dynamic invoking of the getter
				// receive all left objects that are associated to the current right object
				// e.g. all MapLayers of a User
				PersistentSet currentAssocedUsersMapLayers = (PersistentSet)rightGetter.invoke(currentAssocedUser);
				
				/*
				 * http://www.java-forums.org/new-java/20849-how-can-i-avoid-java-util-concurrentmodificationexception-exception.html
				 */
				if(!currentAssocedUsersMapLayers.contains(wmsMapLayerInstanceToAdd)) {
					currentAssocedUsersMapLayers.add(wmsMapLayerInstanceToAdd);
				} else {
//					System.out.println("Hatter schon!");
				}
				
				if (currentAssocedUsersMapLayers.size() == 0) {
					
					currentAssocedUsersMapLayers.add(wmsMapLayerInstanceToAdd);
				}
				
			}
			
			List<? extends Object> allNotAssocedUsers = this.getDatabaseDAO().getEntitiesByExcludingIds(assocications.toArray(), rightClazz);
			
			for (Iterator iterator = allNotAssocedUsers.iterator(); iterator.hasNext();) {
				
				BaseModel currentNotAssocedUser = (BaseModel) iterator.next();
				
				// dynamic invoking of the getter
				// receive all left objects that are associated to the current right object
				// e.g. all MapLayers of a User
				PersistentSet currentNotAssocedUsersMapLayers = (PersistentSet)rightGetter.invoke(currentNotAssocedUser);
				
				/*
				 * http://www.java-forums.org/new-java/20849-how-can-i-avoid-java-util-concurrentmodificationexception-exception.html
				 */
				if(currentNotAssocedUsersMapLayers.contains(wmsMapLayerInstanceToAdd )) {
					currentNotAssocedUsersMapLayers.remove(wmsMapLayerInstanceToAdd);
				} else {
					System.out.println("hatter nie jehabt.....odda?");
				}
				
			}
			
		
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null;
		
	}	
	/**
	 * Determines the properties responsible to map the association between two
	 * entities, such as their getter and setter methods.
	 * 
	 * TODO allow OneToMany as well, only ManyToMany supported ATM
	 * 
	 * @param clazz
	 * @param targetClass
	 * @return
	 * 
	 * @throws IntrospectionException
	 */
	private Map<String, String> detectAssociationProperties(Class<?> clazz, Class<?> targetClass) throws IntrospectionException {

		Map<String, String> classProperties = new HashMap<String, String>();

		PropertyDescriptor[] propertyDescriptors;

		propertyDescriptors = Introspector.getBeanInfo(clazz).getPropertyDescriptors();

		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			
			Method readMethod = propertyDescriptor.getReadMethod();
			Annotation[] annotationsProp = readMethod.getAnnotations();

			for (Annotation annotation : annotationsProp) {

				if (annotation instanceof ManyToMany) {
					
					String dspNameProp = propertyDescriptor.getDisplayName();
					Method writeMethod = propertyDescriptor.getWriteMethod();

					Class classCandidate = ((ManyToMany)annotation).targetEntity();
					String sClassCandidate = classCandidate.getSimpleName();
					
					if (classCandidate.isAssignableFrom(targetClass)) {
						
						classProperties.put("assocProperty", dspNameProp);
						classProperties.put("assocGetter", readMethod.getName());
						classProperties.put("assocSetter", writeMethod.getName());
					}
				}
			}
		}
		
		return classProperties;
	}
	
	/**
	 * Builds an application context object, consisting of:
	 * <ul>
	 * <li>logged in user from session</li>
	 * <li>general application information (language, group, etc...)</li>
	 * <ul>
	 * 
	 * @return HashMap representing the application context as JSON object
	 * @throws ShogunDatabaseAccessException 
	 * @throws Exception
	 */
	@PreAuthorize("hasRole('ROLE_ANONYMOUS') or hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	@Transactional
	public Map<String, Object> getAppContextBySession() throws ShogunServiceException, ShogunDatabaseAccessException {
		
		// get the authorization context, incl. user name
		Authentication authResult = SecurityContextHolder.getContext().getAuthentication();
		// get the user object from database
		List<User> users = getDatabaseDAO().getUserByName(authResult.getName());

		// user-check
		User user = null;
		if (users.size() > 0) {
			user = users.get(0);
		} else {
			throw new ShogunServiceException("No user found, who is logged in at the backend");
		}

		// get corresponding group object from database
		int group_id = user.getGroup_id();
		
		// create an data object containing an JS object for app and user
		// as a sub object of the return object
		Map<String, Object> appDataMap = new HashMap<String, Object>(2);
		appDataMap.put("group_id", group_id);

		// the application context object
		Map<String, Object> appContextMap = new HashMap<String, Object>(2);
		appContextMap.put("app", appDataMap);
		appContextMap.put("user", user);

		return appContextMap;
	}

	/**
	 * Method returns the modules of a user specified by its user name
	 * 
	 * The complete user object is fetched from the database and the modules are
	 * extracted and returned
	 * 
	 * @param username
	 * @return the list of module objects
	 * @throws ShogunDatabaseAccessException 
	 */
	@Transactional
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public List<Module> getModulesByUser(String username) throws ShogunDatabaseAccessException {

		List<User> users = getDatabaseDAO().getUserByName(username);

		User user = null;

		if (users.size() > 0) {
			user = users.get(0);
			List<Module> modules = user.getModules();

			return modules;
		} else {
			return new ArrayList<Module>();
		}
	}

	/**
	 * Method returns all available {@link Module} objects
	 * 
	 * <b>CAUTION: Only if the logged in user has the role ROLE_SUPERADMIN the
	 * function is accessible, otherwise access is denied.</b>
	 * 
	 * @return the list of module objects
	 * @throws Exception
	 *             Specifiy generic errors with an own error message
	 */
	@Transactional
	@PreAuthorize("hasRole('ROLE_SUPERADMIN')")
	public List<Module> getAllModules() throws ShogunServiceException {

		try {
			// get Objects from database
			List<Object> dedicatedModules = getDatabaseDAO().getAllEntities(Module.class);

			// Cast from Object to Module
			List<Module> allModules = new ArrayList<Module>(dedicatedModules.size());
			for (Iterator<Object> iterator = dedicatedModules.iterator(); iterator.hasNext();) {
				Module module = (Module) iterator.next();
				allModules.add(module);
			}

			return allModules;

		} catch (Exception e) {
			throw new ShogunServiceException(
					"Error while fetching all Modules from database" + e.getMessage());
		}

	}

	/**
	 * CAUTION! Not used at the moment, maybe useful for several future use-cases.<br>
	 * Method returns distinct field values of a specified column within an
	 * entity
	 * 
	 * <b>CAUTION: Only if the logged in user has the role ROLE_USER or the role
	 * ROLE_SUPERADMIN the function is accessible, otherwise access is
	 * denied.</b>
	 * 
	 * @return the list of distinct country phone codes as String
	 * @throws ShogunServiceException 
	 */
	@Transactional
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public List<Object> getDistictFieldValues(String entity, String field) throws ShogunServiceException {
		
		Class entityClass = null;
		try {
			entityClass = Class.forName(entity);
		} catch (ClassNotFoundException cnfEx) {
			cnfEx.printStackTrace();
			throw new ShogunServiceException("Provided Class " + entity + " not found " + cnfEx.getMessage());
		}

		// TODO use param for entity MODEL_CLASS_MAP.get(objectType)
		// List<String> codes = gmDAO.getDistinctEntitiesByField(Address.class,
		// field, true);
		List<String> codes = getDatabaseDAO().getDistinctEntitiesByField(
				entityClass, field, true);
		List returnList = new ArrayList();

		for (Iterator<String> iterator = codes.iterator(); iterator.hasNext();) {
			String code = iterator.next();

			List<String> codeAsList = new ArrayList<String>();
			codeAsList.add(code);

			returnList.add(codeAsList);

		}

		return returnList;

	}

	/**
	 * Inserts a new module into the database.
	 * Also creates the needed stubs and config blocks within
	 * the JavaScript parts of SHOGun.
	 * 
	 * @param moduleKey
	 * @param path
	 * @throws IOException
	 */
	@Transactional
	@PreAuthorize("hasRole('ROLE_SUPERADMIN')")
	public void insertModule(Module module, String contextPath)
			throws IOException {
		
		// INSERT IN DB
		 this.getDatabaseDAO().createEntity("Module", module);
		 

		// WRITE RIGHT KEYS IN FILE
		
		java.io.File rightKeys = new java.io.File(contextPath + "WebContent/client/configs/right-keys.js");
		
		if (rightKeys.isFile()) {
			
		    // Note that FileReader is used, not File, since File is not closeable
		    Scanner scanner = new Scanner(new FileReader(rightKeys));
		    StringBuffer sb = new StringBuffer();
		    try {
		      //first use a Scanner to get each line
		      while ( scanner.hasNextLine() ){
		        sb.append(JsHelper.processLineRightKeys(scanner.nextLine(), module.getModule_name()));
		      }
		    }
		    finally {
		      // ensure the underlying stream is always closed
		      // this only has any effect if the item passed to the Scanner
		      // constructor implements closeable (which it does in this case).
		      scanner.close();
		    }
		    
		    // use buffering
		    Writer output = new BufferedWriter(new FileWriter(rightKeys));
		    try {
		      // FileWriter always assumes default encoding is OK!
		      output.write( sb.toString() );
		    }
		    finally {
		      output.close();
		    }
		
		} else {
			throw new IOException("file " + contextPath + "WebContent/client/configs/right-keys.js not found ...");
		}
		
		
		// CREATE TEMPLATE DUE TO NAME CONVENTION
		
		java.io.File moduleTemplate = new java.io.File(contextPath + "WebContent/client/javascript/Terrestris/module/mapclient/TemplateModule.js");
		java.io.File newClassFile = new java.io.File(contextPath + "WebContent/client/javascript/Terrestris/module/mapclient/" + module.getModule_name() + ".js");
		
		if (moduleTemplate.isFile()) {
			
		    //Note that FileReader is used, not File, since File is not Closeable
		    Scanner scanner = new Scanner(new FileReader(moduleTemplate));
		    StringBuffer sb = new StringBuffer();
		    try {
		      //first use a Scanner to get each line
		      while ( scanner.hasNextLine() ){
		        sb.append(JsHelper.processLine(scanner.nextLine(), module.getModule_name()));
		      }
		    }
		    finally {
		      //ensure the underlying stream is always closed
		      //this only has any effect if the item passed to the Scanner
		      //constructor implements Closeable (which it does in this case).
		      scanner.close();
		    }
		    
		    //use buffering
		    Writer output = new BufferedWriter(new FileWriter(newClassFile));
		    try {
		      //FileWriter always assumes default encoding is OK!
		      output.write( sb.toString() );
		    }
		    finally {
		      output.close();
		    }
			

		} else {
			throw new IOException("file " + contextPath + "WebContent/client/javascript/Terrestris/module/mapclient/TemplateModule.js not found ...");
		}

		// WRITE CONFIG FOR LOADER
		
		java.io.File loaderConfigOld = new java.io.File(contextPath + "WebContent/client/javascript/terrestris-suite.config.loader.js");

		if (loaderConfigOld.isFile()) {
			
		    //Note that FileReader is used, not File, since File is not Closeable
		    Scanner scanner = new Scanner(new FileReader(loaderConfigOld));
		    StringBuffer sb = new StringBuffer();
		    try {
		      //first use a Scanner to get each line
		      while ( scanner.hasNextLine() ){
		    	sb.append(JsHelper.processLoaderConfByLine(scanner.nextLine(), module.getModule_name()));
		      }
		    }
		    finally {
		      //ensure the underlying stream is always closed
		      //this only has any effect if the item passed to the Scanner
		      //constructor implements Closeable (which it does in this case).
		      scanner.close();
		    }
		    
		    //use buffering
		    Writer output = new BufferedWriter(new FileWriter(loaderConfigOld));
		    try {
		      //FileWriter always assumes default encoding is OK!
		      output.write( sb.toString() );
		    }
		    finally {
		      output.close();
		    }
		
		} else {
			throw new IOException("file " + contextPath + "WebContent/client/javascript/terrestris-suite.config.loader.js not found ...");
		}
	}
	
	/**
	 * Deletes a module in the database.
	 * 
	 * @param module_name
	 */
	public void deleteModule(String module_name) {
		
		this.getDatabaseDAO().deleteEntityByValue(Module.class, "module_name", module_name);
	}
	
	

//	/**
//	 * TODO: Check if still needed
//	 * 
//	 * @param modules
//	 * @return
//	 */
//	private String createSimpleModulesString(List<Module> modules) {
//
//		// build simple module list as comma separated
//		StringBuffer sb = new StringBuffer();
//		for (Iterator iterator2 = modules.iterator(); iterator2.hasNext();) {
//			Module module = (Module) iterator2.next();
//			sb.append(module.getId() + ",");
//		}
//
//		int lio = sb.lastIndexOf(",");
//
//		if (lio != -1) {
//			String simpleModuleList = sb.substring(0, lio);
//
//			return simpleModuleList;
//		} else {
//			return "";
//		}
//	}
//
//	/**
//	 * TODO: Check if still needed
//	 * 
//	 * @param userName
//	 * @return
//	 * @throws ShogunDatabaseAccessException 
//	 */
//	private String createSimpleModulesString(String userName) throws ShogunDatabaseAccessException {
//
//		List<Module> modules = this.getModulesByUser(userName);
//
//		// build simple module list as comma separated
//		StringBuffer sb = new StringBuffer();
//		for (Iterator iterator2 = modules.iterator(); iterator2.hasNext();) {
//			Module module = (Module) iterator2.next();
//			sb.append(module.getId() + ",");
//		}
//
//		int lio = sb.lastIndexOf(",");
//
//		if (lio != -1) {
//			String simpleModuleList = sb.substring(0, lio - 1);
//			return simpleModuleList;
//		} else {
//			return "";
//		}
//	}

}