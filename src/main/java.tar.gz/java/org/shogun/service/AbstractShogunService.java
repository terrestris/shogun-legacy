/**
 * 
 */
package org.shogun.service;

import org.shogun.dao.DatabaseDAO;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * The service level of SHOGun
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 */
public abstract class AbstractShogunService {
	
	/**
	 * 
	 */
	private DatabaseDAO databaseDAO;
	

	/**
	 * @return the databaseDAO
	 */
	public DatabaseDAO getDatabaseDAO() {
		return databaseDAO;
	}

	/**
	 * Auto generation of an DatabaseDAO instance via dependency injection.
	 * 
	 * @param databaseDAO the databaseDAO to set
	 */
	@Autowired
	public void setDatabaseDAO(DatabaseDAO databaseDAO) {
		this.databaseDAO = databaseDAO;
	}
	

}
