/**
 * 
 */
package org.shogun.service;

import java.util.Set;

import org.shogun.model.MapConfig;
import org.shogun.model.MapLayer;
import org.shogun.model.User;
import org.shogun.model.WfsProxyConfig;
import org.shogun.model.WmsMapLayer;
import org.shogun.model.WmsProxyConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * A service class of SHOGun offering Map related business logic.
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 */
@Service
public class MapAdministrationService extends AbstractShogunService {
	
	/**
	 * 
	 * @param mapConfigs
	 * @return
	 */
	@Transactional
	public MapConfig updateMapConfigs(MapConfig mapConfig) {
		
		return (MapConfig)getDatabaseDAO().updateEntity(MapConfig.class.getSimpleName(),mapConfig);
	}
	
	/**
	 * 
	 * @param wfsProxyConfigs
	 * @return
	 */
	@Transactional
	public WfsProxyConfig updateWfsProxyConfigs(WfsProxyConfig wfsProxyConfig) {
		return (WfsProxyConfig)getDatabaseDAO().updateEntity(WfsProxyConfig.class.getSimpleName(), wfsProxyConfig);
	}
	
	/**
	 * 
	 * @param wmsProxyConfig
	 * @return
	 */
	@Transactional
	public WmsProxyConfig updateWmsProxyConfigs(WmsProxyConfig wmsProxyConfig) {
		return (WmsProxyConfig)getDatabaseDAO().updateEntity(WmsProxyConfig.class.getSimpleName(), wmsProxyConfig);
	}
	
	/**
	 * 
	 * @param wmsMapLayer
	 * @return
	 */
	@Transactional
	public WmsMapLayer createWmsMapLayer(WmsMapLayer wmsMapLayer) {
		
		// create the instance itself
		WmsMapLayer newWmsMapLayer = (WmsMapLayer)getDatabaseDAO().createEntity(WmsMapLayer.class.getSimpleName(), wmsMapLayer);
		
		// add the newly created wmsmaplayer to he current logged in user
		User user = getDatabaseDAO().getUserObjectFromSession();
		Set<MapLayer> currentMapLayersSet = user.getMapLayers();
		currentMapLayersSet.add(newWmsMapLayer);
		
		getDatabaseDAO().updateUser(user);
		
		return newWmsMapLayer;
	}
	
	/**
	 * 
	 * @param wmsMapLayer
	 * @return
	 */
	@Transactional
	public WmsMapLayer updateWmsMapLayer(WmsMapLayer WmsMapLayer) {
		return (WmsMapLayer)getDatabaseDAO().updateEntity(WmsMapLayer.class.getSimpleName(), WmsMapLayer);
	}
	
	/**
	 * 
	 * @param the_id
	 */
	@Transactional
	public void deleteMapLayer(int deleteId) {
		
		// it is only one object - cast to object/bean
		Integer id = new Integer(deleteId);
		getDatabaseDAO().deleteEntity(WmsMapLayer.class, id);
	}
	

}
