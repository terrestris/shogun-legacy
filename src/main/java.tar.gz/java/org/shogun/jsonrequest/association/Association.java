package org.shogun.jsonrequest.association;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * Class represents a complex request to the backend with filter, sort criteria
 * etc...
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: Request.java 424 2011-08-31 09:23:22Z mayer $
 * 
 */
@JsonAutoDetect
public class Association {

	
	private String leftEntity;
	private Integer leftEntityId;
	private String rightEntity;
	private List<Integer> associations;
	
	/**
	 * @return the leftEntity
	 */
	public String getLeftEntity() {
		return leftEntity;
	}
	/**
	 * @param leftEntity the leftEntity to set
	 */
	public void setLeftEntity(String leftEntity) {
		this.leftEntity = leftEntity;
	}
	/**
	 * @return the leftEntityId
	 */
	public Integer getLeftEntityId() {
		return leftEntityId;
	}
	/**
	 * @param leftEntityId the leftEntityId to set
	 */
	public void setLeftEntityId(Integer leftEntityId) {
		this.leftEntityId = leftEntityId;
	}
	/**
	 * @return the rightEntity
	 */
	public String getRightEntity() {
		return rightEntity;
	}
	/**
	 * @param rightEntity the rightEntity to set
	 */
	public void setRightEntity(String rightEntity) {
		this.rightEntity = rightEntity;
	}
	/**
	 * @return the associations
	 */
	public List<Integer> getAssociations() {
		return associations;
	}
	/**
	 * @param associations the associations to set
	 */
	public void setAssociations(List<Integer> associations) {
		this.associations = associations;
	}
	

}