package org.shogun.jsonrequest;

/**
 * Class represents a filter criteria as POJO
 * Given by the client
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: FilterItem.java 423 2011-08-31 09:03:38Z mayer $
 * 
 */
public class FilterItem {

  /** 
   * Field which should be filtered, e.g. 'ID'
   */
  private String fieldName;
  
  /** 
   * Operator of the filter criteria, e.g. 'Smaller' oder 'ILike'
   */
  private String operator;
  
  /** 
   * Operands of the filter criteria, e.g. 12.0
   * Is an Array, so also [12.0. 3.0] is allowed
   */
  private String[] operands;
  

  public void setFieldName (String fieldName) {
	  this.fieldName = fieldName;
  }


  public String getFieldName () {
    return fieldName;
  }
  

  public void setOperator (String operator) {
	  this.operator = operator;
  }
  

  public String getOperator () {
    return operator;
  }
  

  public void setOperands (String[] operands) {
	  this.operands = operands;
  }
  

  public String[] getOperands () {
    return operands;
  }
}