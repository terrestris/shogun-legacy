/**
 * 
 */
package org.shogun.jsonmodel;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import org.shogun.model.WfsProxyConfig;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Marc Jansen
 * 
 * @version $Id$
 *
 */
@JsonAutoDetect
public class WfsProxyConfigList {
	
	List<WfsProxyConfig> wfsProxyConfigs;

	/**
	 * @return the wfsProxyConfigs
	 */
	public List<WfsProxyConfig> getWfsProxyConfigs() {
		return wfsProxyConfigs;
	}

	/**
	 * @param wfsProxyConfigs the wfsProxyConfigs to set
	 */
	public void setWfsProxyConfigs(List<WfsProxyConfig> wfsProxyConfigs) {
		this.wfsProxyConfigs = wfsProxyConfigs;
	}
}