/**
 * 
 */
package org.shogun.jsonmodel;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import org.shogun.model.MapConfig;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id$
 *
 */
@JsonAutoDetect
public class MapConfigList {
	
	List<MapConfig> mapConfigs;

	/**
	 * @return the mapConfigs
	 */
	public List<MapConfig> getMapConfigs() {
		return mapConfigs;
	}

	/**
	 * @param mapConfigs the mapConfigs to set
	 */
	public void setMapConfigs(List<MapConfig> mapConfigs) {
		this.mapConfigs = mapConfigs;
	}

}