/**
 * 
 */
package org.shogun.jsonmodel;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import org.shogun.model.Module;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: UserList.java 402 2011-08-18 14:11:01Z mayer $
 *
 */
@JsonAutoDetect
public class ModuleList {
	
	List<Module> modules;

	/**
	 * @return the modules
	 */
	public List<Module> getModules() {
		return modules;
	}

	/**
	 * @param modules the modules to set
	 */
	public void setModules(List<Module> modules) {
		this.modules = modules;
	}
}