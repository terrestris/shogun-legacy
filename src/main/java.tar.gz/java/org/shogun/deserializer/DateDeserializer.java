package org.shogun.deserializer;

import java.io.IOException;
import java.util.Date;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

/**
 * 
 * Class responsible for deserializing a date
 * Makes a Date object out of an UNIX timestamp 
 * 
 * @author mayer
 *
 */
public class DateDeserializer extends JsonDeserializer<Date> {

	@Override
	public Date deserialize(JsonParser arg0, DeserializationContext arg1)
			throws IOException, JsonProcessingException {
		
		Date d = null;
		
		try {
		
			String s = arg0.getText();
			
			// 1293836400
			Long l = new Long(s);
			d = new Date(l);
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return d;

	}

}