package org.shogun.deserializer;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.io.WKTReader;

/**
 * 
 * Class responsible for deserializing a Geometry
 * Makes a JTS Geometry object out of an WKT String 
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 *
 */
public class GeometryDeserializer extends JsonDeserializer<Geometry> {

	@Override
	public Geometry deserialize(JsonParser arg0, DeserializationContext arg1)
			throws JsonProcessingException {
		
		Geometry geom = null;
		
		try {
			geom = new WKTReader().read(arg0.getText());
			if(geom != null) { 
				//TODO: set the SRID dynamically
				geom.setSRID(900913);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return geom;
	}

}