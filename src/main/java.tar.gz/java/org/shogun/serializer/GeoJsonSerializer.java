package org.shogun.serializer;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.vividsolutions.jts.geom.Geometry;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id$
 * 
 */
public class GeoJsonSerializer extends JsonSerializer<Geometry> {

	@Override
	public void serialize(Geometry value, JsonGenerator jgen,
			SerializerProvider provider) throws IOException,
			JsonProcessingException {

//		// Instanciate need classes
//		GeometryJSON gjson = new GeometryJSON();
//		StringWriter sWriter = new StringWriter();
//		
//		// create GeoJson as String
//		gjson.write(value, sWriter);
//		String sGeoJson = sWriter.toString();
//		
//		// output
//		jgen.writeRawValue(sGeoJson);
//		System.out.println(sGeoJson);
	}

}