package org.shogun.serializer;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.Point;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: WKTSerializer.java 58 2011-05-12 08:40:33Z mayer $
 *
 */
public class WKTSerializer extends JsonSerializer<Geometry> {
	
	@Override
    public void serialize(Geometry value, JsonGenerator jgen, SerializerProvider provider) throws IOException,
                    JsonProcessingException {

            jgen.writeString(value.toText());
    }

}