package org.shogun.serializer;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

/**
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: DateSerializer.java 58 2011-05-12 08:40:33Z mayer $
 *
 */
public class DateSerializer extends JsonSerializer<Date> {
	
	@Override
    public void serialize(Date value, JsonGenerator jgen, SerializerProvider provider) throws IOException,
                    JsonProcessingException {

            DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            
            jgen.writeString(formatter.format(new Date(value.getTime())));
//            jgen.writeString(new Long(value.getTime()/1000).toString());
    }
}

