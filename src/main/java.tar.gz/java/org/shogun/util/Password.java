/**
 * 
 */
package org.shogun.util;

import java.util.Random;

/**
 * @author mayer
 *
 */
public class Password {
	
	/**
	 * 
	 */
	private static final String CHARSET = "!0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	
	
	/**
	 * Helper method to create a random password
	 * 
	 * @param length the length of the password
	 * @return the new password
	 */
	public static String getRandomPassword(int length) {
		
		String charset = CHARSET;

		Random rand = new Random(System.currentTimeMillis());
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int pos = rand.nextInt(charset.length());
			sb.append(charset.charAt(pos));
		}
		return sb.toString();
	}

}
