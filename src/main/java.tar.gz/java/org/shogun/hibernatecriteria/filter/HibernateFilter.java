package org.shogun.hibernatecriteria.filter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Class represents a filter usable in Hibernate queries
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: HibernateFilter.java 423 2011-08-31 09:03:38Z mayer $
 * 
 */
public class HibernateFilter extends Filter {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7073054708538006333L;

	/**
	 * 
	 */
	private Class<? extends Serializable> mainClass = null;

	/**
	 * 
	 * @param mainClass
	 */
	public HibernateFilter(Class<? extends Serializable> mainClass) {
		super();
		this.mainClass = mainClass;
	}

	/**
	 * 
	 */
	public void addFilterItem(FilterItem filterItem) {
		if (filterItem instanceof HibernateFilterItem) {
			super.addFilterItem(filterItem);
		}
	}
	
	/**
	 * Static method creating a Hibernate filter object by a given
	 * JSON request object.
	 * 
	 * @param clazz
	 * @param plainFilter
	 * @return
	 */
	public static HibernateFilter create(Class<? extends Serializable> clazz,
			org.shogun.jsonrequest.Filter plainFilter) {

		HibernateFilter hibernateFilter = null;
		if (plainFilter != null) {
			hibernateFilter = new HibernateFilter(clazz);

			// set the logical operator AND/OR
			if (plainFilter.getLogicalOperator().equalsIgnoreCase("AND")
					|| plainFilter.getLogicalOperator().equalsIgnoreCase("OR")) {

				// decide from request
				hibernateFilter.setLogicalOperator(Operator.valueOf(plainFilter.getLogicalOperator()));
			} else {
				// set default (AND)
				hibernateFilter.setLogicalOperator(Operator.valueOf("AND"));
			}

			// plain filter items from request
			List<org.shogun.jsonrequest.FilterItem> items = plainFilter.getFilterItems();

			// iterate over plain filter items and create hibernate filteritems
			if (items != null) {
				for (org.shogun.jsonrequest.FilterItem item : items) {

					// hibernate filter item
					HibernateFilterItem hibernateItem = new HibernateFilterItem();

					// set field
					hibernateItem.setFieldName(item.getFieldName());
					String operator = item.getOperator();

					// set operator, e.g. Smaller
					hibernateItem.setOperator(FilterItem.Operator.valueOf(operator));

					// set operands
					Object[] operands = item.getOperands();
					int opCount = (operands == null ? 0 : operands.length);
					List<FilterOperand> filterOperands = new ArrayList<FilterOperand>();

					for (int o = 0; o < opCount; o++) {
						filterOperands.add(new FilterOperand(operands[o]));
					}
					hibernateItem.setOperands(filterOperands);

					// add filled item to hibernate filter object
					hibernateFilter.addFilterItem(hibernateItem);
				}
			}
		}
		
		return hibernateFilter;
	}
	
	
	/**
	 * Method creates a Hibernate filter object in a simplified way.
	 * Only one filterItem is used here, which is defined by its fieldname, operator and operands.
	 * 
	 * For more elaborated use-cases please consider using the method 
	 * HibernateFilter create(Class<? extends Serializable> clazz, org.shogun.jsonrequest.Filter plainFilter)
	 * 
	 * @param clazz
	 * @param fieldName
	 * @param operator
	 * @param operands
	 * @return
	 */
	public static HibernateFilter create(Class<? extends Serializable> clazz, String fieldName, 
			String operator, String[] operands) {
		
		org.shogun.jsonrequest.Filter filter = new org.shogun.jsonrequest.Filter();
		
		org.shogun.jsonrequest.FilterItem filterItem = new org.shogun.jsonrequest.FilterItem();
		filterItem.setFieldName(fieldName);
		filterItem.setOperator(operator);
		
		filterItem.setOperands(operands);
		
		List<org.shogun.jsonrequest.FilterItem> filterItems = new ArrayList<org.shogun.jsonrequest.FilterItem>();
		filterItems.add(filterItem);
		
		filter.setFilterItems(filterItems );
		
		HibernateFilter hibernateFilter = HibernateFilter.create((Class<? extends Serializable>) clazz, filter);
		
		return hibernateFilter;

	}

	/**
	 * 
	 * @return
	 */
	public Class<? extends Serializable> getMainClass() {
		return mainClass;
	}

	/**
	 * 
	 * @param mainClass
	 */
	public void setMainClass(Class<? extends Serializable> mainClass) {
		this.mainClass = mainClass;
	}

}