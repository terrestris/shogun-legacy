package org.shogun.hibernatecriteria.filter;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Class defining the filter for a query
 * Has one or more filter items (criteria)
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: Filter.java 58 2011-05-12 08:40:33Z mayer $
 * 
 */
// public class Filter {
public class Filter implements FilterItem {

	private static final long serialVersionUID = -8071606384856284582L;

	/**
	 * Dieses Element stellt einen Verknüpfungsoperator dar.
	 */
	public enum Operator {

		/**
		 * "AND" = Und
		 */
		AND(" AND "),

		/**
		 * "OR" = Oder
		 */
		OR(" OR ");
		private final String _value;

		Operator(String pValue) {
			_value = pValue;
		}

		/**
		 * Liefert den Wert
		 * 
		 * @return Wert
		 */
		public String value() {
			return _value;
		}

		/**
		 * Erzeugen aus dem Wert
		 * 
		 * @param pValue
		 *            Wert
		 * @return
		 */
		public static Operator fromValue(String pValue) {
			for (Operator c : Operator.values()) {
				if (c._value.equals(pValue)) {
					return c;
				}
			}
			throw new IllegalArgumentException(pValue);
		}

	}

	/**
	 * Liste der Filterkriterien
	 */
	private List<FilterItem> filterItems = new Vector<FilterItem>();

	/**
	 * Liste der Verknüpfungsoperatoren
	 */
	private List<Operator> filterOps = new Vector<Operator>();

	/**
   * 
   */
	private Operator logicalOperator;

	/**
	 * Standardmäßiger Verknüpfungsoperator.
	 */
	private Operator defaultOperator = Operator.AND;

	/**
	 * Erzeugt einen Filter.
	 */
	public Filter() {
	}

	public void finalize() throws Throwable {
	}

	/**
	 * Fügt ein Filterkriterium mit dem standardmäßigen Verknüpfungsoperator
	 * hinzu.
	 * 
	 * @param pItem
	 *            Das zusätzliche Filterkriterium.
	 */
	public void addFilterItem(FilterItem pItem) {
		this.addFilterItem(pItem, this.defaultOperator);
	}

	/**
	 * Fügt ein Filterkriterium mit dem angegebenen Verknüpfungsoperator hinzu.
	 * 
	 * @param pItem
	 *            Das zusätzliche Filterkriterium.
	 * @param pOperator
	 *            Der Verknüpfungsoperator.
	 */
	public void addFilterItem(FilterItem pItem, Operator pOperator) {
		if (!Operator.AND.equals(pOperator) && !Operator.OR.equals(pOperator)) {
			throw new IllegalArgumentException("Unknown filter operator: "
					+ pOperator.value());
		}

		if (this.filterItems.size() > 0) {
			this.filterOps.add(pOperator);
		}

		filterItems.add(pItem);
	}

	/**
	 * Liefert das n-te Filterkriterium.
	 * 
	 * @param pIndex
	 *            Index des Filterkriteriums.
	 * 
	 * @return Das n-te Filterkriterium.
	 */
	public FilterItem getFilterItem(int pIndex) {
		return filterItems.get(pIndex);
	}

	/**
	 * Liefert die Anzahl der Filterkriterien.
	 * 
	 * @return Die Anzahl der Filterkriterien.
	 */
	public int getFilterItemCount() {
		return filterItems.size();
	}

	/**
	 * Liefert alle Filterkriterien.
	 * 
	 * @return Alle Filterkriterien.
	 */
	public FilterItem[] getFilterItemArray() {
		return filterItems.toArray(new FilterItem[0]);
	}

	/**
	 * Setzt alle Filterkriterien.
	 * 
	 * @param pNewFilterItemArray
	 *            Alle Filterkriterien.
	 */
	// public void setFilterItemArray (FilterItem[] pNewFilterItemArray) {
	// this._filterItems =
	// new Vector<FilterItem> (Arrays.makeCollection (Arrays
	// .trim (pNewFilterItemArray)));
	// }

	public void setFilterItemArray(List<FilterItem> newFilterItemArray) {
		this.filterItems = newFilterItemArray;
	}

	/**
	 * Liefert den SQL-Ausdruck des Filters.
	 * 
	 * @return SQL-Ausdruck des Filters.
	 */
	public String getSQL() {
		Iterator<FilterItem> iterItems = filterItems.iterator();
		Iterator<Operator> iterOps = filterOps.iterator();
		String exp = null;

		while (iterItems.hasNext()) {
			FilterItem item = (FilterItem) iterItems.next();
			String nextSQL = item.getSQL();
			String nextOp = null;

			if (exp != null) {
				nextOp = iterOps.next().value();
			}

			if (nextSQL != null) {
				if (exp == null) {
					exp = new String();
				} else {
					exp += nextOp;
				}

				if (item instanceof Filter) {
					exp += ("(" + nextSQL + ")");
				} else {
					exp += nextSQL;
				}
			}
		}

		return exp;
	}

	/**
	 * Liefert den standardmäßigen Operator.
	 * 
	 * @return Der standardmäßige Operator.
	 */
	public Operator getDefaultOperator() {
		return defaultOperator;
	}

	/**
	 * Setzt den standardmäßigen Operator.
	 * 
	 * @param pNewDefaultOperator
	 *            Der standardmäßige Operator.
	 */
	public void setDefaultOperator(Operator pNewDefaultOperator) {
		if (!Operator.AND.equals(pNewDefaultOperator)
				&& !Operator.OR.equals(pNewDefaultOperator)) {
			throw new IllegalArgumentException(pNewDefaultOperator.value());
		}

		this.defaultOperator = pNewDefaultOperator;
	}

	/**
	 * Setzt die Liste der Filteroperatoren.
	 * 
	 * @param pNewFilterOperators
	 *            Liste der Filteroperatoren.
	 */
	// public void setFilterOperators (Operator[] pNewFilterOperators) {
	// _filterOps =
	// new Vector<Operator> (Arrays.makeCollection (Arrays
	// .trim (pNewFilterOperators)));
	// }

	public void setFilterOperators(List<Operator> newFilterOperators) {
		filterOps = newFilterOperators;
	}

	/**
	 * Liefert die Liste der Filteroperatoren.
	 * 
	 * @return Liste der Filteroperatoren.
	 */
	public Operator[] getFilterOperators() {
		return filterOps.toArray(new Operator[0]);
	}

	/**
	 * @param logicalOperator
	 *            the logicalOperator to set
	 */
	public void setLogicalOperator(Operator logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	/**
	 * @return the logicalOperator
	 */
	public Operator getLogicalOperator() {
		return logicalOperator;
	}

}