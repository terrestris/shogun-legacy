package org.shogun.hibernatecriteria.filter;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernatespatial.criterion.SpatialRestrictions;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.io.WKTReader;

/**
 * Class for a Hibernate filter condition
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: HibernateFilterItem.java 392 2011-08-18 07:35:54Z mayer $
 * 
 */
public class HibernateFilterItem implements FilterItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7182779834186362411L;

	/**
	 * 
	 */
	private String fieldName;

	/**
	 * 
	 */
	private Operator operator;

	/**
	 * 
	 */
	private List<FilterOperand> operands = new Vector<FilterOperand>();

	
	/**
	 * Creates a Hibernate criterion by filter conditions
	 * 
	 * @return the hibernate criterion object
	 */
	public Criterion makeCriterion(Class mainClass) {

		Criterion criterion = null;

		int operandCount = operands.size();

		// Cast the oprands to the correct data type of the DB field
		Object finalOperand = castOperandToFinalDataType(mainClass, fieldName, (String) operands.get(0).getOperand());
		Object finalOperand2 = null;
		
		if (operandCount == 2) {
			finalOperand2 = castOperandToFinalDataType(mainClass, fieldName, (String) operands.get(1).getOperand());
		}

		switch (operator) {
		case Any:
			break;
		case Between:
			if (operandCount == 2) {
				criterion = Restrictions.between(fieldName, finalOperand, finalOperand2);
			}
			break;
		case Equals:
			criterion = Restrictions.eq(fieldName, finalOperand);
			break;
		case Greater:
			criterion = Restrictions.gt(fieldName, finalOperand);
			break;
		case GreaterEq:
			criterion = Restrictions.ge(fieldName, finalOperand);
			break;
		case In:
			Object[] values = new Object[operandCount];
			for (int o = 0; o < operandCount; o++) {
				values[o] = finalOperand;
			}
			criterion = Restrictions.in(fieldName, values);
			break;
		case IsNull:
			criterion = Restrictions.isNull(fieldName);
			break;
		case Like:
			criterion = Restrictions.like(fieldName, finalOperand);
			break;
		case ILike:
			//TODO remove the ternery operator
			// introduce exclude fields in client
			criterion = (finalOperand != null) ? Restrictions.ilike(fieldName, finalOperand) : null;
			break;
		case NotEquals:
			criterion = Restrictions.ne(fieldName, finalOperand);
			break;
		case NotLike:
			criterion = Restrictions.not(Restrictions.like(fieldName, finalOperand));
			break;
		case NotNull:
			criterion = Restrictions.isNotNull(fieldName);
			break;
		case Smaller:
			criterion = Restrictions.lt(fieldName, finalOperand);
			break;
		case SmallerEq:
			criterion = Restrictions.le(fieldName, finalOperand);
			break;
		case Statement:
			criterion = Restrictions.sqlRestriction(getSQL());
			break;
		case DWITHIN:
			criterion = SpatialRestrictions.within(fieldName, (Geometry)finalOperand);
			break;
		}
		return criterion;
	}
	
	
	@Override
	public String getSQL() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * Cast the operand to the correct data type of the model (DB)
	 * 
	 * @param mainClass
	 * @param fieldName
	 * @param operand
	 * @return
	 */
	private Object castOperandToFinalDataType(Class mainClass, String fieldName, String operand) {

		Object finalOperand = null;

		Field fields[] = mainClass.getDeclaredFields();

		for (int j = 0, m = fields.length; j < m; j++) {

			if (fields[j].getName().equals(this.getFieldName())) {
				// Class Integer
				if (fields[j].getType().equals(java.lang.Integer.class)) {
					
					finalOperand = new Integer(operand);
				}
				// data type int
				else if (fields[j].getType().toString().equals("int")) {
					finalOperand = new Integer(operand);
				} 
				
				
				// Class Double
				else if (fields[j].getType().equals(java.lang.Double.class)) {
					finalOperand = new Double(operand);
				}
				// data type double
				else if (fields[j].getType().toString().equals("double")) {
					finalOperand = new Double(operand);
				} 
				
				
				
				// data type boolean
				else if (fields[j].getType().toString().equals("boolean")) {
					finalOperand = new Boolean(operand);

					// data type DATE
				} else if (fields[j].getType().equals(java.util.Date.class)) {

					try {
						finalOperand = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						finalOperand = formatter.parse(operand);
						
					} catch (ParseException e) {
						System.out.println("ParseException in hibernate filteritem for Date" + e.toString());
						e.printStackTrace();
					}
				
				}	// data type GEOMETRY POINT, etc... 
				else if (fields[j].getType().equals(com.vividsolutions.jts.geom.Point.class) || 
							fields[j].getType().equals(com.vividsolutions.jts.geom.Geometry.class)) {
					
					try {
						
						Geometry point = new WKTReader().read((String)this.getOperands().get(0).getOperand());
						
						// we receive null for a string like %titt% although we catch ParseException
						if (point != null) {
							
							//TODO: set the SRID dynamically
							point.setSRID(900913);
							double distance = Double.parseDouble((String)this.getOperands().get(1).getOperand());
							Geometry g = point.buffer(distance);
							//TODO: set the SRID dynamically
							g.setSRID(900913);
							
							finalOperand = g;
						}
						
	
					} catch (com.vividsolutions.jts.io.ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
				else if (false) {
					// ... more types here
				}
				// DEFAULT is String
				else {
					finalOperand = operand;
				}
			}

		}

		return finalOperand;
	}
	
	
	/*
	 * GETTER AND SETTER
	 */


	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}


	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}


	/**
	 * @return the operator
	 */
	public Operator getOperator() {
		return operator;
	}


	/**
	 * @param operator the operator to set
	 */
	public void setOperator(Operator operator) {
		this.operator = operator;
	}


	/**
	 * @return the operands
	 */
	public List<FilterOperand> getOperands() {
		return operands;
	}


	/**
	 * @param operands the operands to set
	 */
	public void setOperands(List<FilterOperand> operands) {
		this.operands = operands;
	}

}
