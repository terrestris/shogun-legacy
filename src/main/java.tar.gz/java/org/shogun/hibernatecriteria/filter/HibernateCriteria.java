package org.shogun.hibernatecriteria.filter;



import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Class represents a filter criteria for hibernate
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id: HibernateCriteria.java 58 2011-05-12 08:40:33Z mayer $
 * 
 */
public class HibernateCriteria {

//public class HibernateCriteria extends DefaultFilterItem implements FilterItem {
//  
//  /**
//   * 
//   */
//  private static final long serialVersionUID = -7182779834186362411L;
//
//  /** Erzeugt ein Hibernate-Criterion aus der Filterbedingung.
//   * @return
//   */
//  public Criterion makeCriterion() {
//    Criterion criterion = null;
//    Operator operator = this.getOperator();
//    FilterOperand[] operands = this.getOperands();
//    int operandCount = this.getOperandCount();
//    String fieldName = this.getFieldName();
//    switch (operator) {
//    case Any:
//      break;
//    case Between:
//      if (operandCount == 2) {
//        criterion = Restrictions.between (fieldName, operands[0].getOperand(), operands[1].getOperand());
//      }
//      break;
//    case Equals:
//      criterion = Restrictions.eq (fieldName, operands[0].getOperand());
//      break;
//    case Greater:
//      criterion = Restrictions.gt (fieldName, operands[0].getOperand());
//      break;
//    case GreaterEq:
//      criterion = Restrictions.ge (fieldName, operands[0].getOperand());
//      break;
//    case In:
//      Object[] values = new Object[operandCount];
//      for (int o = 0; o < operandCount; o++) {
//        values[o] = operands[o].getOperand ();
//      }
//      criterion = Restrictions.in (fieldName, values);
//      break;
//    case IsNull:
//      criterion = Restrictions.isNull (fieldName);
//      break;
//    case Like:
//      criterion = Restrictions.like (fieldName, operands[0].getOperand());
//      break;
//    case NotEquals:
//      criterion = Restrictions.ne (fieldName, operands[0].getOperand());
//      break;
//    case NotLike:
//      criterion = Restrictions.not (Restrictions.like (fieldName, operands[0].getOperand()));
//      break;
//    case NotNull:
//      criterion = Restrictions.isNotNull (fieldName);
//      break;
//    case Smaller:
//      criterion = Restrictions.lt (fieldName, operands[0].getOperand());
//      break;
//    case SmallerEq:
//      criterion = Restrictions.le (fieldName, operands[0].getOperand());
//      break;
//    case Statement:
//      criterion = Restrictions.sqlRestriction (getSQL());
//      break;
//    }
//    return criterion;    
//  }

}