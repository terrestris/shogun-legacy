package org.shogun.hibernatecriteria.filter;

import java.io.Serializable;

/**
 * This class represents a filter item
 * 
 * TODO: Refactor: remove unused stuff
 * 
 * 
 * @author terretris GmbH & Co. KG
 * @author Christian Mayer
 * 
 */
public interface FilterItem extends Serializable {
	

	public enum Operator {
		
		Equals("Equals", "="), 
		Smaller("Smaller", "< ?"), 
		Greater("Greater", "> ?"), 
		SmallerEq("SmallerEq", "<= ?"), 
		GreaterEq("GreaterEq",">= ?"), 
		Like("Like", " like ?"),
		ILike("ILike", " ilike ?"), 
		Between("Between"," between ? and ?"), 
		Any("Any", " in "), 
		NotNull("NotNull"," is not null"), 
		Statement("Statement", "()"), 
		In("In", " in "), 
		NotEquals("NotEquals", " <> ?"), 
		NotLike("NotLike", " not like ?"), 
		IsNull("IsNull", " is null"),
		DWITHIN("DWITHIN", " Within ( ? ) = TRUE;");

		private final String name;
		private final String value;

		Operator(String givenName, String givenValue) {
			name = givenName;
			value = givenValue;
		}

		/**
		 * Liefert den Wert
		 * 
		 * @return Wert
		 */
		public String value() {
			return value;
		}

		/**
		 * Erzeugen aus dem Wert
		 * 
		 * @param value
		 *            Wert
		 * @return
		 */
		public static Operator fromValue(String value) {
			for (Operator c : Operator.values()) {
				if (c.value.equals(value)) {
					return c;
				}
			}
			throw new IllegalArgumentException(value);
		}

	}

	/**
	 * State of the filter item - unused at the moment
	 */
	public enum State {
		
		ACTIVE("ACTIVE"), 
		PASSIVE("PASSIVE");

		private final String value;

		State(String givenValue) {
			value = givenValue;
		}

		/**
		 * Liefert den Wert
		 * 
		 * @return Wert
		 */
		public String value() {
			return value;
		}

		/**
		 * Create from value
		 * 
		 * @param value the value
		 * @return
		 */
		public static State fromValue(String value) {
			for (State c : State.values()) {
				if (c.value.equals(value)) {
					return c;
				}
			}
			throw new IllegalArgumentException(value);
		}

	}

	/**
	 * name of the state of a filter item - unused at the moment
	 */
	public static final String ITEM_ACTIVE_STATE = "ITEM_ACTIVE_STATE";

	/**
	 * escape sequenz expressed in like syntax - unused at the moment
	 */
	public static final String ESCAPE = "|";

	/**
	 * Returns the SQL statement of the filter criteria 
	 * 
	 * @return
	 */
	public String getSQL();

}
