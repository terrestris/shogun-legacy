package org.shogun.hibernatecriteria.filter;

public class FilterOperand {

	/** Operandenwert */
	private Object operand;
	
	
	public FilterOperand(Object operand) {
		this.operand = operand;
	}

	/**
	 * Liefert den Operandenwert.
	 * 
	 * @return Operandenwert.
	 */
	public Object getOperand() {
		return operand;
	}

	/**
	 * Setzt den Operandenwert.
	 * 
	 * @param pNewOperand
	 *            Operandenwert.
	 */
	public void setOperand(Object operand) {
		this.operand = operand;
	}

}
