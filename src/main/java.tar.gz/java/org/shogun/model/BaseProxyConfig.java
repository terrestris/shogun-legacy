package org.shogun.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * BaseProxyConfig Super Class
 * 
 * @author terrestris GmbH & Co. KG
 * @author Christian Mayer
 * 
 * @version $Id$
 * 
 */
@MappedSuperclass
public class BaseProxyConfig extends BaseModel {
	
//	private String baseUrl;
	private String mandatoryParameters;
	private String validatorClass;
	
	
//	/**
//	 * @return the baseUrl
//	 */
//	@Column(name = "BASEURL", nullable = false)
//	public String getBaseUrl() {
//		return baseUrl;
//	}
//	/**
//	 * @param baseUrl the baseUrl to set
//	 */
//	public void setBaseUrl(String baseUrl) {
//		this.baseUrl = baseUrl;
//	}
	
	/**
	 * @return the mandatoryParameters
	 */
	@Column(name = "MANDATORYPARAMETERS", nullable = false)
	public String getMandatoryParameters() {
		return mandatoryParameters;
	}
	/**
	 * @param mandatoryParameters the mandatoryParameters to set
	 */
	public void setMandatoryParameters(String mandatoryParameters) {
		this.mandatoryParameters = mandatoryParameters;
	}
	
	/**
	 * @return the validatorClass
	 */
	@Column(name = "VALIDATORCLASS", nullable = false)
	public String getValidatorClass() {
		return validatorClass;
	}
	/**
	 * @param validatorClass the validatorClass to set
	 */
	public void setValidatorClass(String validatorClass) {
		this.validatorClass = validatorClass;
	}
}